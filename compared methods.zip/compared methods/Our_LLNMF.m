function Index = Our_LLNMF(X,m1,m2,k,mu,islocal)
% \min_{S,U,V}\mu\sum_{i,j=1}^{n}(||x_{i}-x_{j}||_{2}^{2}S_{ij}+r*S_{ij}^{2})+\lambda Tr(V^{T}L_{S}V)+||X-UV^{T}||_{F}^{2}
%X: mFea*nSmp
%m1: num of row clusters
%m2: num of column clusters,  usually set m1=m2;
%k: neighborhood size
%islocal: 
%           1: only update the similarities of the k neighbor pairs, faster
%           0: update all the similarities
[dim num]=size(X); 
distX = L2_distance_1(X,X);
%distX = sqrt(distX);
[distX1, idx] = sort(distX,2);
A = zeros(num);
rr = zeros(num,1);
eps=1e-9; % set your own tolerance
for i = 1:num
    di = distX1(i,2:k+2);
    rr(i) = 0.5*(k*di(k+1)-sum(di(1:k)));
    id = idx(i,2:k+2);
    A(i,id) = (di(k+1)-di)/(k*di(k+1)-sum(di(1:k))+eps);
end;

% if r <= 0
%     r = mean(rr);
% end;
r = mean(rr);

A0 = (A+A')/2;
DF0 = diag(sum(A0));
LF0 = DF0 - A0;

norms = sqrt(sum((X').^2,2));
X = (X')./(repmat(norms,1,dim)+eps);
X=X';
ITE = 20;
lambda = mu;

%construct data graph
PLF = (abs(LF0) + LF0)/2;
NLF = (abs(LF0) - LF0)/2;

%initialized G using Kmeans
res = kmeans(X,m1,'emptyaction','singleton');
G = zeros(dim,m1);
for i = 1:dim
    G(i,res(i)) = 1;
end
G = G+0.2;

%G = abs(rand(d,m1)); % randomly initialize F

%initialized F using Kmeans
res = kmeans(X',m2,'emptyaction','singleton');
F = zeros(num,m2);
for i = 1:num
    F(i,res(i)) = 1;
end
F = F+0.2;

%F = abs(rand(n,m2)); % randomly initialize G


    F = F.*sqrt((lambda*NLF*F+X'*G)./(lambda*PLF*F+F*(G'*G)+ eps));
    
    % Renormalize so colloums of F have constant energy
    norms = sqrt(sum(F.^2,1));
    F = F./repmat(norms,num,1);
    
    
    G = G.*sqrt((X*F)./(G*(F'*F)+ eps));
    
    % Renormalize so colloums of G have constant energy
    norms = sqrt(sum(G.^2,1));
    G = G./repmat(norms,dim,1);
   % S = S.*repmat(norms',1,m2);



NITER=30;
for iter = 1:NITER
    distf = L2_distance_1(F',F');
    A = zeros(num);
    for i=1:num
        if islocal == 1
            idxa0 = idx(i,2:k+1);
        else
            idxa0 = 1:num;
        end;
        dfi = distf(i,idxa0);
        dxi = distX(i,idxa0);
        ad = -(dxi+lambda*dfi)/(2*r);
        A(i,idxa0) = EProjSimplex_new(ad);
    end;

    A = (A+A')/2;
    D = diag(sum(A)); 
LF = D - A;
PLF = (abs(LF) + LF)/2;
NLF = (abs(LF) - LF)/2;

     F = F.*sqrt((lambda*NLF*F+X'*G)./(lambda*PLF*F+F*(G'*G)+ eps));
    
    % Renormalize so colloums of F have constant energy
    norms = sqrt(sum(F.^2,1));
    F = F./repmat(norms,num,1);
    
    
    G = G.*sqrt((X*F)./(G*(F'*F)+ eps));
    
    % Renormalize so colloums of G have constant energy
    norms = sqrt(sum(G.^2,1));
    G = G./repmat(norms,dim,1);
    
end

Index = litekmeans(F, m1, 'Replicates',20);




